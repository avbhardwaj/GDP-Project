﻿namespace osx_style_iot_smart_house_gui
{
    partial class readings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation1 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(readings));
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuiOSSwitch1 = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuiOSSwitch2 = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuiOSSwitch3 = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuiOSSwitch4 = new Bunifu.Framework.UI.BunifuiOSSwitch();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCircleProgressbar1 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.lbltitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.slide1 = new System.Windows.Forms.Panel();
            this.bunifuSlider1 = new Bunifu.Framework.UI.BunifuSlider();
            this.slider2 = new System.Windows.Forms.Panel();
            this.bunifuSlider2 = new Bunifu.Framework.UI.BunifuSlider();
            this.bunifuTransition1 = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.slide1.SuspendLayout();
            this.slider2.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Roboto Light", 11.75F);
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(43, 58);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(98, 21);
            this.bunifuCustomLabel2.TabIndex = 10;
            this.bunifuCustomLabel2.Text = "Temperature";
            // 
            // bunifuiOSSwitch1
            // 
            this.bunifuiOSSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuiOSSwitch1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuiOSSwitch1.BackgroundImage")));
            this.bunifuiOSSwitch1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuiOSSwitch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuiOSSwitch1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuiOSSwitch1.Location = new System.Drawing.Point(295, 59);
            this.bunifuiOSSwitch1.Name = "bunifuiOSSwitch1";
            this.bunifuiOSSwitch1.OffColor = System.Drawing.Color.Gray;
            this.bunifuiOSSwitch1.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(202)))), ((int)(((byte)(94)))));
            this.bunifuiOSSwitch1.Size = new System.Drawing.Size(35, 20);
            this.bunifuiOSSwitch1.TabIndex = 11;
            this.bunifuiOSSwitch1.Value = true;
            this.bunifuiOSSwitch1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.bunifuiOSSwitch1_MouseMove);
            // 
            // bunifuiOSSwitch2
            // 
            this.bunifuiOSSwitch2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuiOSSwitch2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuiOSSwitch2.BackgroundImage")));
            this.bunifuiOSSwitch2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuiOSSwitch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuiOSSwitch2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuiOSSwitch2.Location = new System.Drawing.Point(295, 100);
            this.bunifuiOSSwitch2.Name = "bunifuiOSSwitch2";
            this.bunifuiOSSwitch2.OffColor = System.Drawing.Color.Gray;
            this.bunifuiOSSwitch2.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(202)))), ((int)(((byte)(94)))));
            this.bunifuiOSSwitch2.Size = new System.Drawing.Size(35, 20);
            this.bunifuiOSSwitch2.TabIndex = 13;
            this.bunifuiOSSwitch2.Value = true;
            this.bunifuiOSSwitch2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.bunifuiOSSwitch2_MouseMove);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Roboto Light", 11.75F);
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(43, 102);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(114, 21);
            this.bunifuCustomLabel1.TabIndex = 12;
            this.bunifuCustomLabel1.Text = "Air Conditioner";
            // 
            // bunifuiOSSwitch3
            // 
            this.bunifuiOSSwitch3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuiOSSwitch3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuiOSSwitch3.BackgroundImage")));
            this.bunifuiOSSwitch3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuiOSSwitch3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuiOSSwitch3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuiOSSwitch3.Location = new System.Drawing.Point(295, 146);
            this.bunifuiOSSwitch3.Name = "bunifuiOSSwitch3";
            this.bunifuiOSSwitch3.OffColor = System.Drawing.Color.Gray;
            this.bunifuiOSSwitch3.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(202)))), ((int)(((byte)(94)))));
            this.bunifuiOSSwitch3.Size = new System.Drawing.Size(35, 20);
            this.bunifuiOSSwitch3.TabIndex = 15;
            this.bunifuiOSSwitch3.Value = true;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel3, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Roboto Light", 11.75F);
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(43, 146);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(53, 21);
            this.bunifuCustomLabel3.TabIndex = 14;
            this.bunifuCustomLabel3.Text = "Lights";
            // 
            // bunifuiOSSwitch4
            // 
            this.bunifuiOSSwitch4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuiOSSwitch4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuiOSSwitch4.BackgroundImage")));
            this.bunifuiOSSwitch4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuiOSSwitch4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTransition1.SetDecoration(this.bunifuiOSSwitch4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuiOSSwitch4.Location = new System.Drawing.Point(295, 192);
            this.bunifuiOSSwitch4.Name = "bunifuiOSSwitch4";
            this.bunifuiOSSwitch4.OffColor = System.Drawing.Color.Gray;
            this.bunifuiOSSwitch4.OnColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(202)))), ((int)(((byte)(94)))));
            this.bunifuiOSSwitch4.Size = new System.Drawing.Size(35, 20);
            this.bunifuiOSSwitch4.TabIndex = 17;
            this.bunifuiOSSwitch4.Value = true;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.bunifuCustomLabel4, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Roboto Light", 11.75F);
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.Gray;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(43, 190);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(81, 21);
            this.bunifuCustomLabel4.TabIndex = 16;
            this.bunifuCustomLabel4.Text = "Door Lock";
            // 
            // bunifuCircleProgressbar1
            // 
            this.bunifuCircleProgressbar1.animated = true;
            this.bunifuCircleProgressbar1.animationIterval = 1;
            this.bunifuCircleProgressbar1.animationSpeed = 100;
            this.bunifuCircleProgressbar1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuCircleProgressbar1.BackgroundImage")));
            this.bunifuTransition1.SetDecoration(this.bunifuCircleProgressbar1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuCircleProgressbar1.Font = new System.Drawing.Font("Roboto Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCircleProgressbar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(24)))), ((int)(((byte)(144)))));
            this.bunifuCircleProgressbar1.LabelVisible = true;
            this.bunifuCircleProgressbar1.LineProgressThickness = 1;
            this.bunifuCircleProgressbar1.LineThickness = 0;
            this.bunifuCircleProgressbar1.Location = new System.Drawing.Point(544, 45);
            this.bunifuCircleProgressbar1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.bunifuCircleProgressbar1.MaxValue = 100;
            this.bunifuCircleProgressbar1.Name = "bunifuCircleProgressbar1";
            this.bunifuCircleProgressbar1.ProgressBackColor = System.Drawing.Color.WhiteSmoke;
            this.bunifuCircleProgressbar1.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(24)))), ((int)(((byte)(144)))));
            this.bunifuCircleProgressbar1.Size = new System.Drawing.Size(167, 167);
            this.bunifuCircleProgressbar1.TabIndex = 18;
            this.bunifuCircleProgressbar1.Value = 60;
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.bunifuTransition1.SetDecoration(this.lbltitle, BunifuAnimatorNS.DecorationType.None);
            this.lbltitle.Font = new System.Drawing.Font("Roboto Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltitle.Location = new System.Drawing.Point(21, 2);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(105, 28);
            this.lbltitle.TabIndex = 19;
            this.lbltitle.Text = "Bathroom";
            // 
            // slide1
            // 
            this.slide1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slide1.BackgroundImage")));
            this.slide1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slide1.Controls.Add(this.bunifuSlider1);
            this.bunifuTransition1.SetDecoration(this.slide1, BunifuAnimatorNS.DecorationType.None);
            this.slide1.Location = new System.Drawing.Point(294, 80);
            this.slide1.Name = "slide1";
            this.slide1.Size = new System.Drawing.Size(238, 40);
            this.slide1.TabIndex = 20;
            this.slide1.Visible = false;
            // 
            // bunifuSlider1
            // 
            this.bunifuSlider1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSlider1.BackgroudColor = System.Drawing.Color.DarkGray;
            this.bunifuSlider1.BorderRadius = 5;
            this.bunifuTransition1.SetDecoration(this.bunifuSlider1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSlider1.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(216)))), ((int)(((byte)(100)))));
            this.bunifuSlider1.Location = new System.Drawing.Point(18, 10);
            this.bunifuSlider1.MaximumValue = 100;
            this.bunifuSlider1.Name = "bunifuSlider1";
            this.bunifuSlider1.Size = new System.Drawing.Size(203, 30);
            this.bunifuSlider1.TabIndex = 0;
            this.bunifuSlider1.Value = 10;
            // 
            // slider2
            // 
            this.slider2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slider2.BackgroundImage")));
            this.slider2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slider2.Controls.Add(this.bunifuSlider2);
            this.bunifuTransition1.SetDecoration(this.slider2, BunifuAnimatorNS.DecorationType.None);
            this.slider2.Location = new System.Drawing.Point(294, 120);
            this.slider2.Name = "slider2";
            this.slider2.Size = new System.Drawing.Size(238, 40);
            this.slider2.TabIndex = 21;
            this.slider2.Visible = false;
            // 
            // bunifuSlider2
            // 
            this.bunifuSlider2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSlider2.BackgroudColor = System.Drawing.Color.DarkGray;
            this.bunifuSlider2.BorderRadius = 5;
            this.bunifuTransition1.SetDecoration(this.bunifuSlider2, BunifuAnimatorNS.DecorationType.None);
            this.bunifuSlider2.IndicatorColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(216)))), ((int)(((byte)(100)))));
            this.bunifuSlider2.Location = new System.Drawing.Point(18, 8);
            this.bunifuSlider2.MaximumValue = 100;
            this.bunifuSlider2.Name = "bunifuSlider2";
            this.bunifuSlider2.Size = new System.Drawing.Size(203, 30);
            this.bunifuSlider2.TabIndex = 0;
            this.bunifuSlider2.Value = 10;
            // 
            // bunifuTransition1
            // 
            this.bunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.VertSlide;
            this.bunifuTransition1.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuTransition1.DefaultAnimation = animation1;
            // 
            // readings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Controls.Add(this.slider2);
            this.Controls.Add(this.slide1);
            this.Controls.Add(this.lbltitle);
            this.Controls.Add(this.bunifuCircleProgressbar1);
            this.Controls.Add(this.bunifuiOSSwitch4);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.bunifuiOSSwitch3);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuiOSSwitch2);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.bunifuiOSSwitch1);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuTransition1.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.Name = "readings";
            this.Size = new System.Drawing.Size(786, 239);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.readings_MouseMove);
            this.slide1.ResumeLayout(false);
            this.slider2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuiOSSwitch bunifuiOSSwitch1;
        private Bunifu.Framework.UI.BunifuiOSSwitch bunifuiOSSwitch2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuiOSSwitch bunifuiOSSwitch3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuiOSSwitch bunifuiOSSwitch4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCircleProgressbar bunifuCircleProgressbar1;
        private Bunifu.Framework.UI.BunifuCustomLabel lbltitle;
        private System.Windows.Forms.Panel slide1;
        private Bunifu.Framework.UI.BunifuSlider bunifuSlider1;
        private System.Windows.Forms.Panel slider2;
        private Bunifu.Framework.UI.BunifuSlider bunifuSlider2;
        private BunifuAnimatorNS.BunifuTransition bunifuTransition1;
    }
}
