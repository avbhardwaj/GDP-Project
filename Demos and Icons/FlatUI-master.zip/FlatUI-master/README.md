FlatUI
======

![Example](screenshots/flatui-example-1.png)

FlatUI is a C# port of the Flat UI theme released by iSynthesis, which
was written in Visual Basic.

Add more here or something maybe.

Credits
-------
- iSynthesis for original code
- AeonHack for parts of the original code